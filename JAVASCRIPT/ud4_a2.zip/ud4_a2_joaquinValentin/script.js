// Función para manejar la entrada de datos
function getInput(question) {
    const answer = prompt(question); // Usamos prompt para obtener la entrada del usuario
    return parseFloat(answer); // Convertimos la respuesta a un número
}

// 1. Saludo
const boton1 = document.getElementById("button1");
boton1.addEventListener("click", function() {
    alert("¡Hola Mundo!");
});

// 2. Área del cuadrado
const boton2 = document.getElementById("button2");
boton2.addEventListener("click", function() {
    const sideLength = getInput("Ingrese la medida del lado del cuadrado: ");
    const squareArea = sideLength * sideLength;
    alert("El área del cuadrado es: " + squareArea);
});

// 3. Área del cuadrado manual
const boton3 = document.getElementById("button3");
boton3.addEventListener("click", function() {
    const lado = getInput("Ingrese la medida del lado del cuadrado: ");
    const area = lado * lado;
    alert("El área del cuadrado es: " + area);
});

// 4. Calculadora básica
const boton4 = document.getElementById("button4");
boton4.addEventListener("click", function() {
    const firstNum = getInput("Introduce el primer número: ");
    const secondNum = getInput("Introduce el segundo número: ");
    alert("La suma es: " + (firstNum + secondNum) +
          "\nLa resta es: " + (firstNum - secondNum) +
          "\nEl producto es: " + (firstNum * secondNum) +
          "\nLa división es: " + (secondNum !== 0 ? firstNum / secondNum : "Indefinido"));
});

// 5. Cálculos del círculo
const boton5 = document.getElementById("button5");
boton5.addEventListener("click", function() {
    const longitudRadio = getInput("Ingrese la longitud del radio: ");
    alert("La longitud de la circunferencia es: " + (2 * longitudRadio * Math.PI) +
          "\nEl área del círculo es: " + (Math.PI * longitudRadio * longitudRadio) +
          "\nEl volumen de la esfera es: " + ((4 * Math.PI * Math.pow(longitudRadio, 3)) / 3));
});

// 6. Descuento
const boton6 = document.getElementById("button6");
boton6.addEventListener("click", function() {
    const priceOfItem = getInput("Ingrese el precio de un artículo: ");
    const actualPrice = getInput("Ingrese el precio real: ");
    alert("Descuento: " + ((priceOfItem - actualPrice) / actualPrice));
});

// 7. Conversión de millas a metros
const boton7 = document.getElementById("button7");
boton7.addEventListener("click", function() {
    const miles = getInput('Millas que se quieren convertir: ');
    alert('La distancia en metros es: ' + (miles * 1609.34)); // 1 milla = 1609.34 metros
});

// 8. Ordenar dos números
const boton8 = document.getElementById("button8");
boton8.addEventListener("click", function() {
    const number1 = getInput('Número 1: ');
    const number2 = getInput('Número 2: ');
    alert(`El orden ascendente de los números es: ${Math.min(number1, number2)} y ${Math.max(number1, number2)}`);
});

// 9. Comparar dos números
const boton9 = document.getElementById("button9");
boton9.addEventListener("click", function() {
    const firstNumber = getInput("Número 1: ");
    const secondNumber = getInput("Número 2: ");
    const outputMessage = (firstNumber === secondNumber) ? "Los números son iguales" : (firstNumber > secondNumber) ? "El Número 1 es mayor" : "El Número 2 es mayor";
    alert(outputMessage);
});

// 10. Número máximo de tres
const boton10 = document.getElementById("button10");
boton10.addEventListener("click", function() {
    const firstNumber = getInput("Introduce el primer número: ");
    const secondNumber = getInput("Introduce el segundo número: ");
    const thirdNumber = getInput("Introduce el tercer número: ");
    alert("El número máximo es: " + Math.max(firstNumber, secondNumber, thirdNumber));
});

// 11. Sumar dos números
const boton11 = document.getElementById("button11");
boton11.addEventListener("click", function() {
    const firstNumber = getInput("Introduce el primer número: ");
    const secondNumber = getInput("Introduce el segundo número: ");
    alert("La suma es: " + (firstNumber + secondNumber));
});

// 12. Mayor de dos números
const boton12 = document.getElementById("button12");
boton12.addEventListener("click", function() {
    const primer = getInput("Primer número: ");
    const segundo = getInput("Segundo número: ");
    alert("El mayor es: " + Math.max(primer, segundo));
});

// 13. Positivo o negativo
const boton13 = document.getElementById("button13");
boton13.addEventListener("click", function() {
    const number = getInput("Introduce un número: ");
    alert("El número es " + (number >= 0 ? "positivo" : "negativo"));
});